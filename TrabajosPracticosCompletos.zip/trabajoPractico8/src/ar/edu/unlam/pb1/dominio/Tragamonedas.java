package ar.edu.unlam.pb1.dominio;

public class Tragamonedas {
//	private Tambor tambor1;
//	private Tambor tambor2;
//	private Tambor tambor3;
//
//	public Tragamonedas() {
//
//	}
//
//	public int getPosicion() {
//		return 0;
//	}
//
//	public void girar(int numero) {
//		tambor1.girarNumero(numero, false);
//		tambor2.girarNumero(numero, false);
//		tambor3.girarNumero(numero, false);
//	}
}
