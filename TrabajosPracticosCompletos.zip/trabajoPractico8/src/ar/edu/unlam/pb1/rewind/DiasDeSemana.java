package ar.edu.unlam.pb1.rewind;

public enum DiasDeSemana {
	DOMINGO, LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO
}
