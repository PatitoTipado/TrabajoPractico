package ar.edu.unlam.pb1.rewind;

public enum Temperaturas {
	CELISUS, FARENHEIT, KELVIN
}
