package ar.edu.unlam.pb1.interfaz;

import ar.edu.unlam.pb1.dominio.Tragamonedas;

public class TestTragramonedas {

	public static void main(String[] args) {
		Tragamonedas tragramoneda = new Tragamonedas();
		System.out.println(tragramoneda);
	}

}
