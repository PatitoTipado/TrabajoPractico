package ar.edu.unlam.pb1.dominio;

public enum DiasDeSemana {
	DOMINGO, LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO
}
