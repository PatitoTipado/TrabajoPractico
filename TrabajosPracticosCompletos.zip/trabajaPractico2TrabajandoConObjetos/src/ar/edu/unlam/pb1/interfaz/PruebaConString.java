package ar.edu.unlam.pb1.interfaz;

public class PruebaConString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String minuscula="java es case sensitive";//distingue entre mayuscula y miniscula
		System.out.println(minuscula.length());
		String mayuscula="JAVA ES CASE SENSITIVE";
		System.out.println(mayuscula+".");
	}

}
