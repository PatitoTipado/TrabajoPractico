package ar.edu.unlam.pb1.rewind;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculadora casio=new Calculadora();
		System.out.println(casio.contarDivisores(10));
	}

}
