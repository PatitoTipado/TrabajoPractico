package ar.edu.unlam.pb1.enums;

public enum MenuPrincipal {
	//toman un valor predeterminado que comienza desde 0
//	   0	  1		    2		   3	   4 
	SUMAR, RESTAR, MULTIPLICAR, DIVIDIR, SALIR,
	
}
