package ar.edu.unlam.pb1.interfaz;

//import ar.edu.unlam.pb1.rewind.Persona;

public class PruebaEstadisticasDePersonas {
	public static void main(String[] args) {
		// datos
//		Persona persona = null;
//		int contadorSobrePeso = 0;
//		int contadorBajoPeso = 0;
//		int contadorPesoNormal = 0;
//		int cantidadDePersonas = 50;
//		double contadorPesoPromedio = 0;
//		double promedioEncuesta = 0;
//		double promedioEdadDePersonasBajoPeso = 0;
//		double promedioEdadDePersonasSobrePeso = 0;
//		double promedioEdadDePersonasPesoNormal = 0;
//		int i=0;
//		// bucle
//		while (i<cantidadDePersonas) {
//			persona = new Persona(Math.random() * 200, (int) Math.random() * 100);
//			contadorPesoPromedio += persona.pesar();
//			if (persona.pesar() < 50) {
//				promedioEdadDePersonasBajoPeso += persona.getEdad();
//				contadorBajoPeso++;
//			} else if (persona.pesar() > 150) {
//				promedioEdadDePersonasSobrePeso += persona.getEdad();
//				contadorSobrePeso++;
//			} else if (persona.pesar() > 50 && persona.pesar() < 150) {
//				promedioEdadDePersonasPesoNormal += persona.getEdad();
//				contadorPesoNormal++;
//			}
//			i++;
//		}
//		// resultado
//		promedioEncuesta = contadorPesoPromedio / cantidadDePersonas;
//		System.out.println("el peso promedio de la encuesta es de: " + promedioEncuesta);
//		System.out.println("La cantidad de personas con bajo peso es de: " + contadorBajoPeso);
//		System.out.println("La cantidad de personas con Sobre peso es de: " + contadorSobrePeso);
//		System.out.println("La cantidad de personas con peso normal es de: " + contadorPesoNormal);
//		System.out.println();
//		promedioEdadDePersonasSobrePeso /= cantidadDePersonas;
//		promedioEdadDePersonasPesoNormal /= cantidadDePersonas;
	}

}
