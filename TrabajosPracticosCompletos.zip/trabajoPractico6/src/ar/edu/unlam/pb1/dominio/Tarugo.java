package ar.edu.unlam.pb1.dominio;

public class Tarugo {
	private final int LONGITUD;
	public Tarugo(int longitud) {
		this.LONGITUD=longitud;
	}
	public int getLongitud() {
		return LONGITUD;
	}
}
