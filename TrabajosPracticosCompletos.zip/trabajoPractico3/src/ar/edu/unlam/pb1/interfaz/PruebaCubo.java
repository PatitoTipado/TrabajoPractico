package ar.edu.unlam.pb1.interfaz;

public class PruebaCubo {
	public static void main(String[] args) {
		
	}
}
